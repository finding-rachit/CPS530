#!/usr/bin/perl
use CGI':standard';
use strict;
print "Content-type: text/html \n\n";

print "<HTML>";
print "<HEAD>";
print "<TITLE>CPS530</TITLE>";
print qq~<link rel="stylesheet" type="text/css" href="mystyle.css">\n~;
print "</HEAD>";
print "<BODY>";
print "<p>This is my first Perl program </p>";
print "</BODY>";
print "</HTML>";